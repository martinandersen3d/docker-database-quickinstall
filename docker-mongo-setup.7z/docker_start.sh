#!/bin/bash
LANG=en_US.UTF-8

cd /media/m/DataLinux/Code/Docker/docker-database-quickinstall && sudo docker-compose start
